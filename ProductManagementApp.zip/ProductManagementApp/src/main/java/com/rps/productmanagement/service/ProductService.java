package com.rps.productmanagement.service;

import java.util.List;

import com.rps.productmanagement.model.Product;

public interface ProductService {

	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String deleteProduct(int productId);

	public abstract Product getProduct(int productId);

	public abstract List<Product> getAllProducts();
}
