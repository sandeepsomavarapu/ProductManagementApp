package com.rps.productmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rps.productmanagement.dao.ProductDao;
import com.rps.productmanagement.model.Product;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao dao;

	@Override
	public String addProduct(Product product) {

		return dao.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {

		return dao.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return dao.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return dao.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return dao.getAllProducts();
	}

}
