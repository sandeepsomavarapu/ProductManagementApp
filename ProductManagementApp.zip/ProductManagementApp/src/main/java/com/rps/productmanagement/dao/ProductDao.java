package com.rps.productmanagement.dao;

import java.util.List;

import com.rps.productmanagement.model.Product;

public interface ProductDao {
	public abstract String addProduct(Product product);//persist

	public abstract String updateProduct(Product product);//merge

	public abstract String deleteProduct(int productId);//remove

	public abstract Product getProduct(int productId);//find

	public abstract List<Product> getAllProducts();//JPQL
}
