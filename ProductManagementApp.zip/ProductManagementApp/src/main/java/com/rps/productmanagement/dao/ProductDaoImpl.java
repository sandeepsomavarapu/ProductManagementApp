package com.rps.productmanagement.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.rps.productmanagement.model.Product;

@Repository
@Transactional
public class ProductDaoImpl implements ProductDao {
	@PersistenceContext
	EntityManager entityManager;// JPA

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		return "Product Inserted Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		entityManager.merge(product);
		return "Product Update Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		entityManager.remove(getProduct(productId));
		return "Product Deleted Successfully";
	}

	@Override
	public Product getProduct(int productId) {

		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {
		Query result = entityManager.createQuery("select e from Product e");
		return result.getResultList();
	}

//select * from products_info where product_price between 40000 and 50000;
	@Override
	public List<Product> getAllProductsInBetween(int iprice, int fprice) {

		Query result = entityManager.createQuery("select e from Product e where e.productPrice between ?1 and ?2");
		result.setParameter(1, iprice);
		result.setParameter(2, fprice);
		return result.getResultList();
	}

//select * from products_info where product_name='dell';
	@Override
	public List<Product> getAllProductsByname(String pname) {
		Query result = entityManager.createQuery("select e from Product e where e.productName=?1");
		result.setParameter(1, pname);
		return result.getResultList();
	}

}
